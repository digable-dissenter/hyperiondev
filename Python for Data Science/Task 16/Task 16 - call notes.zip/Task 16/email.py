#An SMS Simulation
# 1. Email class as a template to create objects
inbox = []
class Email(object):

    # This is the class definition including all the variables specified
    # To note: has_been_read and is_spam are set to False
    def __init__(self, email_contents, from_address):
        self.inbox = []
        self.email_contents = email_contents
        self.from_address = from_address
        self.has_been_read = False
        self.is_spam = False

    # As per note above, the following two methods set the has_been_read and is_spam to True 
    def mark_as_read(self):
        return self.has_been_read == True

    def mark_as_spam(self):
        return self.is_spam == True



# 2. Utility functions to operate on the list of objects
def add_email(email_contents,from_address):
    email = Email(email_contents, from_address)
    inbox.append(email)

# I admit I was stumped here: I don't know how to call the add_method
# in order to add objects to the inbox list
# I've commented out the would be code so the program could run

# email_contents = 
# from_address = 
# inbox.append(add_email(email_contents,from_address))



# get_count simply appends the count_emails variable for every email in inbox
def get_count():         # return a value, or change the state internally of the program
    # count_emails variable will be referenced in get_count method
    count_emails = 0
    for i in inbox:
        count_emails += 1

    return count_emails

    # return len(self.inbox)
        
# get_email accepts a user's input which will then be used as an index
# for which specific email in inbox will be shown
# This will of course parse through every index in the inbox to get specified email
def get_email(user_input_index):
    email_content = ''
    for i in range(len(inbox)):  
        if i == user_input_index:
            email_content += self.email_contents
        else:
            email_content
    return email_content.split()

    # return inbox[user_input_index]

# get_unread_emails parses through each index in the inbox list
# and finds emails where the has_been_read attribute is set to False  
def get_unread_emails(self):
    unread = ''
    for i in self.inbox:
        if self.has_been_read == False:
            unread += self.has_been_read + '\t'
        else:
            unread
    return unread.strip()

# Similar logic to get_unread_emails method above except it pulls through
# any emails marked as spam
def get_spam_emails(self):
    spam = ''
    for i in self.inbox:
        if self.is_spam == True:
            spam += self.is_spam + '\t'
        else:
            spam
    return spam.strip()

# delete simply uses the input index to find a specific email in the inbox list
# and deletes it from the inbox list
def delete(self,index):
    for i in inbox:
        if i == index:
            del inbox[i]                
        
user_choice = ""
## email_inbox = Email(False,

while user_choice != "quit":
    user_choice = input("What would you like to do - read/mark spam/send/quit?")
    if user_choice == "read":
        # Self-explanatory: user would want to read unread emails, so call get_unread_emails() method to get list of unread emails      
        # How would you define get_unread_emails()?
        get_unread_emails() 
        # Once email has been read, they may be marked as such
        # How would you define mark_as_read()?
        mark_as_read() 
    elif user_choice == "mark spam":
        # As per user choice, this method would then mark an email as spam
        # How would you define mark_as_spam()?
        mark_as_spam()    
        # I've called this method here just in case use wants to view which emails are spam
        # How would you define get_spam_emails()?
        get_spam_emails() 
    elif user_choice == "send":
        # Which of the methods in the class would you call here? I had no idea
        pass 
    elif user_choice == "quit":
        print("Goodbye")
    else:
        print("Oops - incorrect input")
